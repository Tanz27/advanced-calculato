let display = document.getElementById("display");
let historyList = document.getElementById("historyList");

function appendValue(val) {
  display.value += val;
}

function clearDisplay() {
  display.value = '';
}

function backspace() {
  display.value = display.value.slice(0, -1);
}

function calculate() {
  try {
    let result = eval(display.value);
    addToHistory(display.value + " = " + result);
    display.value = result;
  } catch {
    alert("Error in expression");
  }
}

function addToHistory(entry) {
  let li = document.createElement("li");
  li.textContent = entry;
  historyList.prepend(li);
}

function toggleTheme() {
  document.body.classList.toggle("dark");
  const themeBtn = document.getElementById("themeToggle");
  themeBtn.textContent = document.body.classList.contains("dark") ? "☀️" : "🌙";
}

// Enable keyboard input
document.addEventListener("keydown", function (e) {
  if (e.key.match(/[0-9+\-*/().]/)) {
    appendValue(e.key);
  } else if (e.key === "Enter") {
    e.preventDefault();
    calculate();
  } else if (e.key === "Backspace") {
    backspace();
  } else if (e.key === "Escape") {
    clearDisplay();
  }
});